from autoencoder import generate_model, generate_synthetic_data
print("Hello World!")
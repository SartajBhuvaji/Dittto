# dittto
PyPI for generating synthetic Tabular Data

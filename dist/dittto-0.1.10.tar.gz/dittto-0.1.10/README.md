# pip package build
[![Library Test](https://github.com/SartajBhuvaji/pip-package-build/actions/workflows/library_workflow.yml/badge.svg)](https://github.com/SartajBhuvaji/pip-package-build/actions/workflows/library_workflow.yml)

PyPI for generating synthetic Tabular Data

# In development

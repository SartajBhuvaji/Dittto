from dittto import generate_autoencoder, generate_synthetic_data

print("Hello World!")